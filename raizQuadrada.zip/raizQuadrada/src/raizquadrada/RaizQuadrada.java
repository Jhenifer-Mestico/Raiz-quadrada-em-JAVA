/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package raizquadrada;

/**
 *
 * @author Jhenifer
 */
import static java.lang.Math.sqrt;
import java.util.Scanner;
public class RaizQuadrada {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner inputData = new Scanner(System.in);
    float a,b,c;
    double delta,x1,x2;
    System.out.println("Digite  valor do coeficiente A");
    a = inputData.nextFloat(); 
    
    System.out.println("Digite  valor do coeficiente B");
    b = inputData.nextFloat(); 
    
    System.out.println("Digite  valor do coeficiente C");
    c = inputData.nextFloat(); 
    
    delta = b*b - 4*a*c;
    x1 = (-b+sqrt(delta))/2*a;
    x2 = (-b-sqrt(delta))/2*a;   
     
     System.out.println("Delta = " + delta + "X1=" + x1 + "X2=" + x2 );
    }
    
}
